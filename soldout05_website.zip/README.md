# soldout05
Premium men's fashion website.

## Upload to GitHub
Upload `index.html` to your repository.
Then enable GitHub Pages:
Settings → Pages → Deploy from branch → main → /(root) → Save.

Contact details are already included in the website.
