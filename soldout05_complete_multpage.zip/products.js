const PRODUCTS=[
{id:1,name:"Essential Black Tee",cat:"T-Shirts",price:699,img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=85",desc:"A clean everyday black T-shirt with an easy regular fit."},
{id:2,name:"Oversized Street Tee",cat:"T-Shirts",price:799,img:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=800&q=85",desc:"Relaxed streetwear-inspired fit for casual days."},
{id:3,name:"Premium Casual Shirt",cat:"Shirts",price:999,img:"https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=85",desc:"A versatile shirt designed for smart-casual styling."},
{id:4,name:"Classic Denim Shirt",cat:"Shirts",price:1099,img:"https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=800&q=85",desc:"Classic denim styling with a modern everyday look."},
{id:5,name:"Regular Fit Jeans",cat:"Jeans",price:1299,img:"https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=800&q=85",desc:"A versatile regular-fit denim for daily wear."},
{id:6,name:"Dark Blue Jeans",cat:"Jeans",price:1399,img:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=85",desc:"Deep-blue denim with a clean timeless finish."},
{id:7,name:"Everyday Joggers",cat:"Joggers",price:899,img:"https://images.unsplash.com/photo-1552902865-b72c031ac5ea?auto=format&fit=crop&w=800&q=85",desc:"Comfort-first joggers for relaxed everyday outfits."},
{id:8,name:"Urban Black Joggers",cat:"Joggers",price:949,img:"https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=800&q=85",desc:"Minimal black joggers with an urban streetwear feel."}
];