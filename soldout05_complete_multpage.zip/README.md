# soldout05 — Multi-page Men's Fashion Store

## Pages
- Home: `index.html`
- Shop: `shop.html`
- Categories: `category.html?cat=...`
- Product: `product.html?id=...`
- Cart: `cart.html`
- Checkout: `checkout.html`
- About: `about.html`
- Contact: `contact.html`

## GitHub Pages
Upload all files to the repository root. Then:
Settings → Pages → Deploy from branch → main → /(root) → Save.

The site uses localStorage for the cart and opens WhatsApp for order confirmation.
